    <footer class="section">
        <div class="center grey-text">Copyright 2025 Ninja Pizza</div>
    </footer>
</body>