<div class="w3-bar w3-sand">
  <a href="index.php" class="w3-bar-item w3-button">New order</a>
  <a href="viewOrders.php" class="w3-bar-item w3-button">View orders</a>
</div>