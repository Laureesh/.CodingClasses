<div class="w3-bar w3-light-grey">
  <a href="OrderForm.php" class="w3-bar-item w3-button">New Order</a>  
  <a href="ViewOrders.php" class="w3-bar-item w3-button">View Orders</a>
</div>